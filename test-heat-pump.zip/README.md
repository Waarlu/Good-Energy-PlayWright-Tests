# Introduction

Repository to run against the Heat Pump test website. Only tests are included in this repository

# Getting Started

Clone repository and `yarn install`

# Build and Test

`yarn pw:headless` to run the tests
`yarn pw:report`to see the created report with the test run
